/**
 * 
 */
package com.billsplit.constant;

/**
 * @author Rohit
 *
 */
public enum Currency {
INR,USD,EUR,GBP;
}
