/**
 * 
 */
package com.billsplit.constant;

/**
 * @author Rohit
 *
 */
public enum ShareType {

	RATIO,PERCENTAGE,AMOUNT;
}
