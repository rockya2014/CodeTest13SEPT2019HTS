/**
 * 
 */
package com.billsplit.hibernate4.dao;

import org.hibernate.Session;

/**
 * @author Rohit
 *
 */
public interface HibernateSessionFactory {

	Session getSession();
	
}
